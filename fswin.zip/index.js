'use strict';
var v = process.version.match(/(\d+\.)(\d+)\./);
v[2] = parseInt(v[2]);
if (v[2] % 2) {
	v[2]++;
}
module.exports = require('./' + v[1] + v[2] + '.x' + '/' + process.arch + '/fswin.node');