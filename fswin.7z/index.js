'use strict';
var v, isElectron = process.versions && process.versions.electron;
if (process.platform === 'win32') {
    v = (isElectron ? process.versions.electron : process.version).match(/(\d+\.)(\d+)\./);
    if (isElectron || v[1] === '0.') {
		v[2] = parseInt(v[2]);
		if (!isElectron && v[2] % 2) {
			v[2]++;
		}
	} else {
		v[2] = 'x';
	}
console.log(v);
	module.exports = require((isElectron ? './electron/' : './node/') + v[1] + v[2] + '.x' + '/' + process.arch + '/fswin.node');
} else {
	throw 'this module only works on windows';
}