'use strict';
if (process.platform === 'win32') {
	module.exports = require((process.versions && process.versions.electron ? './electron/' : './node/') + process.arch + '/fswin.node');
} else {
	module.exports = null;
}