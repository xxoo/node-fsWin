'use strict';
module.exports = process.platform === 'win32' ? require('./' + process.arch + '/fswin.node') : null;